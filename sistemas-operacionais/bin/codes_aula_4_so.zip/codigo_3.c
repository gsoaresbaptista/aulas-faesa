#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t cid = fork();

    if (cid < 0) exit(1);

    if (cid == 0) {
        // FILHO: Morre rápido
        printf("[Filho] PID %d: Tchau, virei um zumbi...\n", getpid());
        exit(0); 
    } else {
        // PAI: Fica vivo por 20 segundos sem dar wait()
        printf("[Pai] PID %d: Criei o filho %d, mas não vou ler o estado dele agora.\n", getpid(), cid);
        printf("[Pai]: Verifique o terminal agora com: ps aux | grep 'Z'\n");
        
        sleep(20); // Janela de tempo para você rodar o comando no terminal
        
        printf("[Pai]: Acordei! Agora vou dar wait() e limpar o zumbi.\n");
        wait(NULL); 
        
        sleep(5); // Tempo para você ver que o zumbi sumiu
    }

    return 0;
}