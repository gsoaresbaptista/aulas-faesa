#!/bin/bash

# Uso: ./repetir.sh <quantidade> <comando>
VEZES=$1
COMANDO=$2

for i in $(seq $VEZES); do
    # Executa o comando passado como argumento
    $COMANDO
    # Adiciona a quebra de linha extra ao final
    echo -e "\n"
done