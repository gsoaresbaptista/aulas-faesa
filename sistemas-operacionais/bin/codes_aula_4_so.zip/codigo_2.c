#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int x = 100;
    pid_t cid;
    int status; // Variável para armazenar o status de saída do filho

    cid = fork();

    if (cid < 0) {
        perror("fork failed");
        return 1;
    }

    if (cid == 0) {
        // FILHO
        x = x + 50;
        printf("Filho: x = %d (Meu PID: %d)\n", x, getpid());
        _exit(0); // Boa prática: terminar o filho explicitamente
    } else {
        // PAI
        // cid aqui é o PID do filho que acabou de ser criado
        // 0 como terceiro argumento significa "bloqueie até o filho terminar"
        waitpid(cid, &status, 0); 
        
        printf("Pai: x = %d (Esperou pelo filho %d)\n", x, cid);
    }

    return 0;
}