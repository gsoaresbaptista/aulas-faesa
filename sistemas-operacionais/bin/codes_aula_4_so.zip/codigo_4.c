#include <stdio.h>
#include <unistd.h>

int main() {
    for (int i = 0; i < 3; i++) {
        fork();
    }

    printf("Olá! PID=%d PPID=%d\n", getpid(), getppid());
    sleep(20);
}

