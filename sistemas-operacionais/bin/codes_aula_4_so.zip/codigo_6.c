#include <pthread.h>
#include <stdio.h>

int saldo = 100;

void* deposito(void* arg) {
    saldo = saldo + 50;
    return NULL;
}

int main() {
    pthread_t t1;
    pthread_create(&t1, NULL, deposito, NULL);
    pthread_join(t1, NULL);
    printf("Saldo Final: %d\n", saldo);
}
