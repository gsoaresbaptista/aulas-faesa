#include <stdio.h>
#include <unistd.h>

int main() {
    pid_t pid;
    pid = fork(); // Clona o processo

    if (pid < 0) {
        printf("Erro na criação!\n");
    } else if (pid == 0) {
        // Retorno 0 indica que estamos no FILHO
        printf("Eu sou o FILHO! Meu PID é %d\n", getpid());
    } else {
        // Retorno > 0 indica que estamos no PAI (pid é o ID do filho)
        printf("Eu sou o PAI! Criei o filho com PID %d\n", pid);
    }

    return 0;
}