#include <pthread.h>
#include <stdio.h>

void* minha_tarefa(void* arg) {
    printf("Olá da Thread! ID: %ld\n", pthread_self());
    return NULL;
}

int main() {
    pthread_t tid;
    // Cria a thread
    pthread_create(&tid, NULL, minha_tarefa, NULL);
    // Aguarda a thread terminar (similar ao wait)
    pthread_join(tid, NULL);
    printf("Thread principal finalizada.\n");
    return 0;
}