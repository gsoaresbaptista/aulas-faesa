#include <stdio.h>
#include <pthread.h>

long contador = 0;

void* incremento(void* arg) {
    // Aumentamos para 1 milhão para dar tempo das threads colidirem
    for (int i = 0; i < 1000000; i++) {
        contador++;
    }
    return NULL;
}

int main() {
    pthread_t t1, t2;

    // Criamos duas threads que vão atacar a mesma variável global
    pthread_create(&t1, NULL, incremento, NULL);
    pthread_create(&t2, NULL, incremento, NULL);

    // Esperamos ambas terminarem
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    // O esperado seria 2.000.000, mas o resultado será menor e aleatório
    printf("Resultado esperado: 2000000\n");
    printf("Resultado real:     %ld\n", contador);

    return 0;
}