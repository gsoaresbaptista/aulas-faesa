#ifndef LIVRO_H
#define LIVRO_H

typedef struct {
    char titulo[50];
    int codigo;
    float multa_diaria;
    int exemplares;
} Livro;

float potencial_multa_livro(const Livro *l);
float potencial_multa_total(Livro livros[], int n);
float calcular_multa_devolucao(const Livro *l, int dias_atraso);
int buscar_livro(Livro livros[], int n, int codigo);
int aplicar_emprestimo(Livro *l, int quantidade);
void aplicar_devolucao(Livro *l);
void aplicar_reajuste(Livro *l, int percentual);

#endif
