#include "livro.h"

int buscar_livro(Livro livros[], int n, int codigo) {
    for (int i = 0; i < n; i++) {
        if (livros[i].codigo == codigo) {
            return i;
        }
    }

    return -1;
}

int aplicar_emprestimo(Livro *l, int quantidade) {
    if (l->exemplares >= quantidade) {
        l->exemplares -= quantidade;
        return 1;
    }

    return 0;
}

float potencial_multa_livro(const Livro *l) {
    return l->multa_diaria * l->exemplares;
}

/*
 * TODO implemente aqui:
 * - potencial_multa_total
 * - calcular_multa_devolucao
 * - aplicar_devolucao
 * - aplicar_reajuste
 */
