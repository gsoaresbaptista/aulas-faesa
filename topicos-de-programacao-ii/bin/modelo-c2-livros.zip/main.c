#include <stdio.h>
#include "livro.h"

int main() {
    int n, m, tipo, codigo, valor;
    Livro livros[100];

    int emprestimos = 0;
    int devolucoes = 0;
    int reajustes = 0;
    int operacoes_invalidas = 0;
    float total_multas = 0.0;

    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        scanf("%s %d %f %d",
            livros[i].titulo,
            &livros[i].codigo,
            &livros[i].multa_diaria,
            &livros[i].exemplares
        );
    }

    scanf("%d", &m);

    for (int i = 0; i < m; i++) {
        scanf("%d %d %d", &tipo, &codigo, &valor);

        int pos = buscar_livro(livros, n, codigo);

        if (pos == -1) {
            printf("Livro nao encontrado\n");
            operacoes_invalidas++;
        } else if (tipo == 0) {
            if (aplicar_emprestimo(&livros[pos], valor) == 1) {
                emprestimos++;
            } else {
                printf("Exemplares indisponiveis\n");
                operacoes_invalidas++;
            }
        } else if (tipo == 1) {
            /*
             * TODO devolucao:
             * 1. calcular a multa usando valor como dias de atraso
             * 2. somar a multa em total_multas
             * 3. aplicar a devolucao no livro
             * 4. incrementar devolucoes
             */
        } else if (tipo == 2) {
            /*
             * TODO reajuste:
             * 1. usar valor como percentual inteiro
             * 2. aplicar o reajuste no livro
             * 3. incrementar reajustes
             */
        }
    }

    /*
     * TODO relatorio e sumario:
     * 1. imprimir todos os livros
     * 2. calcular o potencial total de multas
     * 3. imprimir os contadores e totais finais
     */

    return 0;
}
