## Contrato Sintatico do Slang

Este contrato define o primeiro marco do parser descendente recursivo.

### Programa

```text
program        -> declaration* EOF
declaration    -> function_decl | var_decl | statement
```

### Declaracoes

```text
function_decl  -> "fn" IDENT "(" params? ")" "->" type block
params         -> param ("," param)*
param          -> IDENT ":" type
var_decl       -> IDENT ":" type "=" expression
type           -> "int" | "float" | "bool" | "char" | "string" | "void"
```

### Comandos

```text
statement      -> if_stmt
               | loop_stmt
               | return_stmt
               | break_stmt
               | continue_stmt
               | assign_stmt
               | call_stmt
               | block

block          -> "{" declaration* "}"
if_stmt        -> "if" expression block ("else" block | "else" if_stmt)?
loop_stmt      -> "loop" block | "loop" expression block
return_stmt    -> "return" expression?
break_stmt     -> "break"
continue_stmt  -> "continue"
assign_stmt    -> IDENT "=" expression
call_stmt      -> call
```

### Expressoes

```text
expression     -> or
or             -> and (("or" | "||") and)*
and            -> equality (("and" | "&&") equality)*
equality       -> comparison (("==" | "!=") comparison)*
comparison     -> term ((">" | ">=" | "<" | "<=") term)*
term           -> factor (("+" | "-") factor)*
factor         -> unary (("*" | "/" | "%") unary)*
unary          -> ("!" | "not" | "-") unary | call
call           -> primary ("(" arguments? ")")*
arguments      -> expression ("," expression)*
primary        -> NUMBER | STRING | CHAR | "true" | "false" | IDENT | "(" expression ")"
```

### Observacoes

- Comandos nao dependem de quebra de linha para terminar.
- Declaracoes de variavel devem sempre ter inicializador neste marco.
- `loop { ... }` representa um laco infinito.
- `loop expr { ... }` representa um laco condicional.
- Chamadas sao validas tanto em expressoes quanto como comandos isolados.
