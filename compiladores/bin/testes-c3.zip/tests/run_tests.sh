#!/bin/bash

COMPILER="./build/compiler"
SLANG_VM="./build/slang-vm"
TEST_ROOT="./tests"
TARGET="${1:-all}"
PASS=0
FAIL=0
TOTAL=0

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
RESET='\033[0m'

run_suite() {
    local suite_name="$1"
    local mode="$2"
    local input_dir="$TEST_ROOT/$suite_name/input"
    local expected_dir="$TEST_ROOT/$suite_name/expected"

    echo ""
    echo -e "${BOLD}=============================================${RESET}"
    echo -e "${BOLD}   EXECUTANDO TESTES DE ${suite_name^^}${RESET}"
    echo -e "${BOLD}=============================================${RESET}"

    for input_file in "$input_dir"/*.slang; do
        local test_name expected_file actual_output expected_output

        [ -e "$input_file" ] || continue

        test_name=$(basename "${input_file%.slang}")
        expected_file="$expected_dir/$test_name.txt"
        TOTAL=$((TOTAL + 1))

        if [ ! -f "$expected_file" ]; then
            echo -e "  ${YELLOW}[PULA]${RESET} $suite_name/$test_name"
            continue
        fi

        actual_output=$("$COMPILER" "$mode" "$input_file" 2>&1)
        expected_output=$(<"$expected_file")

        if [ "$actual_output" = "$expected_output" ]; then
            echo -e "  ${GREEN}[OK]${RESET} $suite_name/$test_name"
            PASS=$((PASS + 1))
        else
            echo -e "  ${RED}[FALHA]${RESET} $suite_name/$test_name"
            FAIL=$((FAIL + 1))
            echo -e "         ${BOLD}--- Esperado ---${RESET}"
            while IFS= read -r line; do
                printf '         %s\n' "$line"
            done <<< "$expected_output"
            echo -e "         ${BOLD}--- Obtido ---${RESET}"
            while IFS= read -r line; do
                printf '         %s\n' "$line"
            done <<< "$actual_output"
        fi
    done
}

run_vm_suite() {
    local suite_name="vm"
    local input_dir="$TEST_ROOT/$suite_name/input"
    local expected_dir="$TEST_ROOT/$suite_name/expected"
    local asm_file
    asm_file=$(mktemp /tmp/slang_vm_test_XXXXXX.slasm)

    echo ""
    echo -e "${BOLD}=============================================${RESET}"
    echo -e "${BOLD}   EXECUTANDO TESTES DE ${suite_name^^}${RESET}"
    echo -e "${BOLD}=============================================${RESET}"

    for input_file in "$input_dir"/*.slang; do
        local test_name expected_file actual_output expected_output

        [ -e "$input_file" ] || continue

        test_name=$(basename "${input_file%.slang}")
        expected_file="$expected_dir/$test_name.txt"
        TOTAL=$((TOTAL + 1))

        if [ ! -f "$expected_file" ]; then
            echo -e "  ${YELLOW}[PULA]${RESET} $suite_name/$test_name"
            continue
        fi

        if ! "$COMPILER" "code" "$input_file" > "$asm_file" 2>/dev/null; then
            echo -e "  ${RED}[FALHA - COMPILACAO]${RESET} $suite_name/$test_name"
            FAIL=$((FAIL + 1))
            continue
        fi

        actual_output=$("$SLANG_VM" "$asm_file" 2>/dev/null)
        expected_output=$(<"$expected_file")

        if [ "$actual_output" = "$expected_output" ]; then
            echo -e "  ${GREEN}[OK]${RESET} $suite_name/$test_name"
            PASS=$((PASS + 1))
        else
            echo -e "  ${RED}[FALHA]${RESET} $suite_name/$test_name"
            FAIL=$((FAIL + 1))
            echo -e "         ${BOLD}--- Esperado ---${RESET}"
            while IFS= read -r line; do
                printf '         %s\n' "$line"
            done <<< "$expected_output"
            echo -e "         ${BOLD}--- Obtido ---${RESET}"
            while IFS= read -r line; do
                printf '         %s\n' "$line"
            done <<< "$actual_output"
        fi
    done

    rm -f "$asm_file"
}

if [ ! -f "$COMPILER" ]; then
    echo -e "${RED}[ERRO]${RESET} Compilador nao encontrado em '$COMPILER'."
    echo -e "        Execute: ${YELLOW}cmake -B build && cmake --build build${RESET}"
    exit 1
fi

if [ ! -f "$SLANG_VM" ]; then
    echo -e "${RED}[ERRO]${RESET} slang-vm nao encontrado em '$SLANG_VM'."
    echo -e "        Execute: ${YELLOW}cmake -B build && cmake --build build${RESET}"
    exit 1
fi

case "$TARGET" in
    lexer)
        run_suite "lexer" "lex"
        ;;
    parser)
        run_suite "parser" "parse"
        ;;
    vm)
        run_vm_suite
        ;;
    all)
        run_suite "lexer" "lex"
        run_suite "parser" "parse"
        run_vm_suite
        ;;
    *)
        echo -e "${RED}[ERRO]${RESET} Suite desconhecida '$TARGET'. Use: lexer | parser | vm | all"
        exit 1
        ;;
esac

echo ""
echo -e "${BOLD}=============================================${RESET}"
echo -e "${BOLD}   RESULTADO: ${GREEN}$PASS PASSARAM${RESET}${BOLD} | ${RED}$FAIL FALHARAM${RESET}${BOLD} | $TOTAL TOTAL${RESET}"
echo -e "${BOLD}=============================================${RESET}"
echo ""

if [ "$FAIL" -gt 0 ]; then
    exit 1
fi

exit 0
