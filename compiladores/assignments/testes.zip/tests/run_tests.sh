#!/bin/bash
# =============================================================================
# Script de Testes Automatizados - Analisador Léxico
# Disciplina: Compiladores
# =============================================================================
#
# USO:
#   ./tests/run_tests.sh
#
# O script deve ser executado a partir da RAIZ do projeto, após a compilação:
#   cmake -B build && cmake --build build
#   ./tests/run_tests.sh
#
# CONVENÇÃO:
#   Cada teste é composto por um par de arquivos na pasta tests/:
#     - <nome>.slang    -> entrada fornecida ao compilador
#     - <nome>.expected -> saída esperada (apenas as linhas de tokens)
#
# =============================================================================

COMPILER="./build/compiler"
TESTS_DIR="./tests"
PASS=0
FAIL=0
TOTAL=0

# Cores para o terminal
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
RESET='\033[0m'

echo ""
echo -e "${BOLD}=============================================${RESET}"
echo -e "${BOLD}   TESTES AUTOMATIZADOS - LEXER SLANG       ${RESET}"
echo -e "${BOLD}=============================================${RESET}"
echo ""

# Verifica se o compilador foi buildado
if [ ! -f "$COMPILER" ]; then
    echo -e "${RED}[ERRO]${RESET} Compilador não encontrado em '$COMPILER'."
    echo -e "       Execute primeiro: ${YELLOW}cmake -B build && cmake --build build${RESET}"
    exit 1
fi

# Itera sobre todos os arquivos .slang na pasta de testes
for input_file in "$TESTS_DIR"/*.slang; do
    # Deriva o nome do arquivo de saída esperada
    base="${input_file%.slang}"
    expected_file="${base}.expected"
    test_name=$(basename "$base")

    TOTAL=$((TOTAL + 1))

    # Verifica se o arquivo .expected existe
    if [ ! -f "$expected_file" ]; then
        echo -e "  ${YELLOW}[SKIP]${RESET} $test_name — arquivo .expected não encontrado"
        continue
    fi

    # Executa o compilador e captura a saída real
    # Filtra as linhas de cabeçalho (=== ... ===) para comparar apenas os tokens
    actual_output=$("$COMPILER" "$input_file" 2>&1 | grep -v "^===" )

    expected_output=$(cat "$expected_file")

    # Compara a saída real com a esperada
    if [ "$actual_output" = "$expected_output" ]; then
        echo -e "  ${GREEN}[PASS]${RESET} $test_name"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}[FAIL]${RESET} $test_name"
        FAIL=$((FAIL + 1))
        echo -e "         ${BOLD}--- Esperado: ---${RESET}"
        echo "$expected_output" | sed 's/^/         /'
        echo -e "         ${BOLD}--- Obtido:   ---${RESET}"
        echo "$actual_output" | sed 's/^/         /'
        echo ""
    fi
done

# Relatório final
echo ""
echo -e "${BOLD}=============================================${RESET}"
echo -e "${BOLD}   RESULTADO: ${GREEN}$PASS PASSOU${RESET}${BOLD} | ${RED}$FAIL FALHOU${RESET}${BOLD} | $TOTAL TOTAL${RESET}"
echo -e "${BOLD}=============================================${RESET}"
echo ""

# Retorna código de erro se algum teste falhou (útil para CI/CD)
if [ "$FAIL" -gt 0 ]; then
    exit 1
fi

exit 0
